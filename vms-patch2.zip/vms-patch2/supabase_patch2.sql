-- VMS Patch 2 Migration
-- Run in Supabase SQL Editor

-- 1. Rider applications table (for signup apply-as-rider flow)
CREATE TABLE IF NOT EXISTS rider_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  status text NOT NULL DEFAULT 'pending', -- pending | approved | rejected
  applied_at timestamptz DEFAULT now(),
  reviewed_at timestamptz,
  rejection_reason text
);

ALTER TABLE rider_applications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own rider application"
ON rider_applications FOR SELECT TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "Users can insert own rider application"
ON rider_applications FOR INSERT TO authenticated
WITH CHECK (user_id = auth.uid());

-- Admins can do everything (service role)
CREATE POLICY "Service role full access to rider applications"
ON rider_applications FOR ALL TO service_role USING (true);

-- 2. Add charge_applied column to bank_withdrawals (if not exists)
ALTER TABLE bank_withdrawals ADD COLUMN IF NOT EXISTS charge_applied numeric DEFAULT 0;

-- 3. Index for rider applications lookup
CREATE INDEX IF NOT EXISTS rider_applications_status_idx ON rider_applications(status);
CREATE INDEX IF NOT EXISTS rider_applications_user_id_idx ON rider_applications(user_id);
