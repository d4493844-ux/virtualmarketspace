# VMS UI & Settings Upgrade — Apply Instructions

## What's in this patch

| File | What changed |
|------|-------------|
| `src/index.css` | Full design system: glassmorphism, card shadows, rounded tokens, animation library |
| `src/components/BottomNav.tsx` | Glass nav, active indicator, gradient Post button |
| `src/pages/SettingsPage.tsx` | Complete redesign: icon cards, gradient badges, profile header |
| `src/pages/BillingPage.tsx` | Paystack integrated, stats cards, full transaction history |
| `src/pages/VerificationPage.tsx` | Plan picker, Paystack popup, real status check |
| `src/pages/NotificationSettingsPage.tsx` | Supabase-saved toggles, save button, icon rows |
| `src/pages/PrivacySettingsPage.tsx` | Supabase-saved toggles, security notice |
| `src/pages/PasswordSecurityPage.tsx` | Password strength meter, match indicator, 2FA toggle |
| `src/pages/EditProfilePage.tsx` | Avatar upload to Supabase Storage, business type select |
| `supabase_migration.sql` | Adds `notification_settings` + `privacy_settings` columns |

---

## Step 1 — Upload this zip to your Codespace

Drag and drop `vms-upgrade.zip` into your Codespace file explorer, or use the terminal:

```bash
# If you put the zip in /workspaces:
ls /workspaces/vms-upgrade.zip
```

---

## Step 2 — Extract and copy files

```bash
cd /workspaces

# Unzip the upgrade
unzip -o vms-upgrade.zip -d /tmp/vms-upgrade

# Copy all upgraded source files into your project
cp /tmp/vms-upgrade/src/index.css /workspaces/virtualmarketspace/src/index.css
cp /tmp/vms-upgrade/src/components/BottomNav.tsx /workspaces/virtualmarketspace/src/components/BottomNav.tsx
cp /tmp/vms-upgrade/src/pages/SettingsPage.tsx /workspaces/virtualmarketspace/src/pages/SettingsPage.tsx
cp /tmp/vms-upgrade/src/pages/BillingPage.tsx /workspaces/virtualmarketspace/src/pages/BillingPage.tsx
cp /tmp/vms-upgrade/src/pages/VerificationPage.tsx /workspaces/virtualmarketspace/src/pages/VerificationPage.tsx
cp /tmp/vms-upgrade/src/pages/NotificationSettingsPage.tsx /workspaces/virtualmarketspace/src/pages/NotificationSettingsPage.tsx
cp /tmp/vms-upgrade/src/pages/PrivacySettingsPage.tsx /workspaces/virtualmarketspace/src/pages/PrivacySettingsPage.tsx
cp /tmp/vms-upgrade/src/pages/PasswordSecurityPage.tsx /workspaces/virtualmarketspace/src/pages/PasswordSecurityPage.tsx
cp /tmp/vms-upgrade/src/pages/EditProfilePage.tsx /workspaces/virtualmarketspace/src/pages/EditProfilePage.tsx

echo "✅ Files copied!"
```

---

## Step 3 — Run the Supabase migration

1. Open your Supabase dashboard → **SQL Editor**
2. Paste the contents of `supabase_migration.sql`
3. Click **Run**

This adds `notification_settings` and `privacy_settings` columns to your `users` table, creates a `paystack_webhooks` log table, and adds helpful indexes.

---

## Step 4 — Add Paystack public key to your .env

```bash
# Open your .env file
nano /workspaces/virtualmarketspace/.env

# Add this line (use your actual key from dashboard.paystack.com):
VITE_PAYSTACK_PUBLIC_KEY=pk_live_xxxxxxxxxxxxxxxxxxxxxxxx

# For testing first, use:
VITE_PAYSTACK_PUBLIC_KEY=pk_test_xxxxxxxxxxxxxxxxxxxxxxxx
```

> Get your keys at: https://dashboard.paystack.com/#/settings/developer

---

## Step 5 — Restart dev server

```bash
cd /workspaces/virtualmarketspace
npm run dev
```

---

## Step 6 — Optional: Paystack webhook (for production)

To automatically verify payments server-side, set up a Paystack webhook:

1. In Paystack Dashboard → Settings → API Keys & Webhooks
2. Set webhook URL to: `https://YOUR_SUPABASE_PROJECT.supabase.co/functions/v1/paystack-webhook`
3. Create a Supabase Edge Function that verifies the `x-paystack-signature` header

The webhook events you care about: `charge.success`, `subscription.create`, `subscription.disable`

---

## Troubleshooting

**CSS variables not working?**
Make sure `src/index.css` is imported in `src/main.tsx`:
```tsx
import './index.css'
```

**Avatar upload failing?**
Make sure you have a Supabase Storage bucket called `media` with public access enabled.
Go to: Storage → Create bucket → Name: `media` → Public: ON

**Paystack popup not opening?**
The script loads dynamically. Make sure `VITE_PAYSTACK_PUBLIC_KEY` is set correctly and you're using https in production.
