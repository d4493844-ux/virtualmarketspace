-- Migration: Add settings columns + Paystack webhook support
-- Run in your Supabase SQL Editor

-- Add notification_settings column
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS notification_settings JSONB DEFAULT '{
    "push_notifications": true,
    "email_notifications": true,
    "sms_notifications": false,
    "likes": true,
    "comments": true,
    "new_followers": true,
    "messages": true,
    "order_updates": true,
    "promotions": false,
    "product_updates": true
  }'::jsonb;

-- Add privacy_settings column
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS privacy_settings JSONB DEFAULT '{
    "profile_visibility": true,
    "show_activity": true,
    "allow_messages": true,
    "show_email": false,
    "show_phone": false,
    "show_followers": true,
    "show_following": true
  }'::jsonb;

-- Create paystack_webhooks table for logging
CREATE TABLE IF NOT EXISTS paystack_webhooks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event TEXT NOT NULL,
  reference TEXT,
  amount INTEGER,
  email TEXT,
  status TEXT,
  raw_payload JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fast lookups
CREATE INDEX IF NOT EXISTS idx_paystack_webhooks_reference ON paystack_webhooks(reference);
CREATE INDEX IF NOT EXISTS idx_paystack_webhooks_email ON paystack_webhooks(email);
CREATE INDEX IF NOT EXISTS idx_verification_requests_user_id ON verification_requests(user_id);
CREATE INDEX IF NOT EXISTS idx_verification_requests_status ON verification_requests(status, payment_status);

-- Backfill existing users with default settings
UPDATE users
SET notification_settings = '{
  "push_notifications": true,
  "email_notifications": true,
  "sms_notifications": false,
  "likes": true,
  "comments": true,
  "new_followers": true,
  "messages": true,
  "order_updates": true,
  "promotions": false,
  "product_updates": true
}'::jsonb
WHERE notification_settings IS NULL;

UPDATE users
SET privacy_settings = '{
  "profile_visibility": true,
  "show_activity": true,
  "allow_messages": true,
  "show_email": false,
  "show_phone": false,
  "show_followers": true,
  "show_following": true
}'::jsonb
WHERE privacy_settings IS NULL;
