-- VMS patch migration: is_banned, push_subscriptions
-- Run in Supabase SQL Editor

-- Add is_banned column to users (if not exists)
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_banned boolean DEFAULT false;

-- Push notification subscriptions table
CREATE TABLE IF NOT EXISTS push_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  endpoint text NOT NULL,
  p256dh text NOT NULL,
  auth text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, endpoint)
);

ALTER TABLE push_subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own push subscriptions"
ON push_subscriptions FOR ALL TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Ensure notifications table has actor_id index for perf
CREATE INDEX IF NOT EXISTS notifications_user_id_idx ON notifications(user_id);
CREATE INDEX IF NOT EXISTS notifications_created_at_idx ON notifications(created_at DESC);

-- Index for conversations lookup
CREATE INDEX IF NOT EXISTS conversations_participant_ids_idx ON conversations USING gin(participant_ids);
