// ─── PASTE THIS INTO AdminDashboardPage.tsx ───────────────────────────────────
// Add 'support' to the activeSection type and tab list, then add this component

// 1. Add to the activeSection type:
// useState<'overview' | 'verifications' | 'ads' | 'users' | 'riders' | 'content' | 'support'>

// 2. Add to the tabs array:
// { id: 'support', label: 'Support', icon: MessageCircle, badge: 0 },

// 3. Add this route in App.tsx:
// <Route path="/support-agent" element={<SupportAgentPage />} />

// 4. Add this section in the content area:
// {activeSection === 'support' && <SupportSection />}

// 5. Import at top of AdminDashboardPage:
// import { MessageCircle } from 'lucide-react'; // add to existing import

// ─── SupportSection Component (add OUTSIDE AdminDashboardPage function) ────────

import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { MessageCircle, Plus, Trash2, Eye, EyeOff, Copy, CheckCircle, User } from 'lucide-react';

type Agent = {
  id: string;
  email: string;
  display_name: string;
  is_active: boolean;
  is_online: boolean;
  created_at: string;
  last_seen: string;
};

type SupportSession = {
  id: string;
  status: string;
  created_at: string;
  user?: { display_name: string; email: string };
  agent?: { display_name: string };
};

export function SupportSection() {
  const { user } = useAuth();
  const [agents, setAgents] = useState<Agent[]>([]);
  const [sessions, setSessions] = useState<SupportSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateAgent, setShowCreateAgent] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [creating, setCreating] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [copied, setCopied] = useState(false);
  const [generatedCreds, setGeneratedCreds] = useState<{ email: string; password: string } | null>(null);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    setLoading(true);
    const [{ data: agentsData }, { data: sessionsData }] = await Promise.all([
      supabase.from('support_agents').select('*').order('created_at', { ascending: false }),
      supabase.from('support_sessions').select('*, user:users!support_sessions_user_id_fkey(display_name, email)').order('created_at', { ascending: false }).limit(20),
    ]);
    setAgents((agentsData as Agent[]) || []);
    setSessions((sessionsData as SupportSession[]) || []);
    setLoading(false);
  };

  const createAgent = async () => {
    if (!newName.trim() || !newEmail.trim() || !newPassword.trim()) {
      alert('All fields required');
      return;
    }
    if (newPassword.length < 8) {
      alert('Password must be at least 8 characters');
      return;
    }

    setCreating(true);

    // Hash password with SHA-256 (same as agent login uses)
    const encoder = new TextEncoder();
    const data = encoder.encode(newPassword);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

    const { error } = await supabase.from('support_agents').insert({
      display_name: newName.trim(),
      email: newEmail.toLowerCase().trim(),
      password_hash: hashHex,
      created_by: user?.id,
      is_active: true,
      is_online: false,
    });

    if (error) {
      alert('Error: ' + error.message);
      setCreating(false);
      return;
    }

    setGeneratedCreds({ email: newEmail.toLowerCase().trim(), password: newPassword });
    setNewName(''); setNewEmail(''); setNewPassword('');
    setShowCreateAgent(false);
    setCreating(false);
    loadData();
  };

  const toggleAgentStatus = async (agentId: string, currentStatus: boolean) => {
    await supabase.from('support_agents').update({ is_active: !currentStatus }).eq('id', agentId);
    loadData();
  };

  const deleteAgent = async (agentId: string) => {
    if (!confirm('Delete this agent? They will lose access immediately.')) return;
    await supabase.from('support_agents').delete().eq('id', agentId);
    loadData();
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const statusColor: Record<string, string> = {
    bot: '#3b82f6', waiting: '#f59e0b', active: '#10b981', resolved: '#6366f1', closed: '#94a3b8',
  };

  if (loading) return <div style={{ textAlign: 'center', padding: 40 }}>Loading...</div>;

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24, flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h2 style={{ fontSize: 22, fontWeight: 800, color: '#0f172a', margin: 0 }}>Support Management</h2>
          <p style={{ fontSize: 13, color: '#64748b', marginTop: 4 }}>{agents.length} agents · {sessions.filter(s => s.status === 'waiting').length} waiting · {sessions.filter(s => s.status === 'active').length} active</p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <a href="/support-agent" target="_blank" style={{ padding: '10px 16px', borderRadius: 12, background: '#eff6ff', color: '#1d4ed8', fontWeight: 700, fontSize: 13, textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Eye size={14} /> Agent Portal
          </a>
          <button onClick={() => setShowCreateAgent(true)} style={{ padding: '10px 16px', borderRadius: 12, background: '#0f172a', color: '#fff', fontWeight: 700, fontSize: 13, border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Plus size={14} /> Add Agent
          </button>
        </div>
      </div>

      {/* Generated credentials banner */}
      {generatedCreds && (
        <div style={{ background: '#f0fdf4', border: '1px solid #86efac', borderRadius: 16, padding: 20, marginBottom: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <p style={{ fontWeight: 700, color: '#166534', margin: '0 0 8px', display: 'flex', alignItems: 'center', gap: 6 }}>
                <CheckCircle size={16} /> Agent created! Share these credentials:
              </p>
              <p style={{ color: '#166534', fontSize: 13, margin: '0 0 4px' }}><strong>Login URL:</strong> {window.location.origin}/support-agent</p>
              <p style={{ color: '#166534', fontSize: 13, margin: '0 0 4px' }}><strong>Email:</strong> {generatedCreds.email}</p>
              <p style={{ color: '#166534', fontSize: 13, margin: 0 }}><strong>Password:</strong> {generatedCreds.password}</p>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={() => copyToClipboard(`Login: ${window.location.origin}/support-agent\nEmail: ${generatedCreds.email}\nPassword: ${generatedCreds.password}`)}
                style={{ padding: '8px 12px', borderRadius: 10, background: copied ? '#dcfce7' : '#166534', color: 'white', border: 'none', cursor: 'pointer', fontWeight: 600, fontSize: 12, display: 'flex', alignItems: 'center', gap: 4 }}>
                {copied ? <><CheckCircle size={12} /> Copied!</> : <><Copy size={12} /> Copy All</>}
              </button>
              <button onClick={() => setGeneratedCreds(null)} style={{ width: 32, height: 32, borderRadius: '50%', background: 'rgba(22,101,52,0.1)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <span style={{ color: '#166534', fontSize: 16 }}>×</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create agent modal */}
      {showCreateAgent && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div style={{ background: 'white', borderRadius: 20, padding: 28, width: '100%', maxWidth: 440, boxShadow: '0 20px 60px rgba(0,0,0,0.3)' }}>
            <h3 style={{ fontSize: 18, fontWeight: 800, color: '#0f172a', margin: '0 0 20px' }}>Create Support Agent</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 6 }}>Full Name</label>
                <input value={newName} onChange={e => setNewName(e.target.value)} placeholder="e.g. Adaeze Support"
                  style={{ width: '100%', padding: '10px 14px', borderRadius: 10, border: '1.5px solid #e2e8f0', fontSize: 14, outline: 'none', boxSizing: 'border-box', color: '#0f172a' }} />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 6 }}>Email Address</label>
                <input type="email" value={newEmail} onChange={e => setNewEmail(e.target.value)} placeholder="agent@virtualmarketspace.com"
                  style={{ width: '100%', padding: '10px 14px', borderRadius: 10, border: '1.5px solid #e2e8f0', fontSize: 14, outline: 'none', boxSizing: 'border-box', color: '#0f172a' }} />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 6 }}>Password</label>
                <div style={{ position: 'relative' }}>
                  <input type={showPassword ? 'text' : 'password'} value={newPassword} onChange={e => setNewPassword(e.target.value)} placeholder="Min 8 characters"
                    style={{ width: '100%', padding: '10px 44px 10px 14px', borderRadius: 10, border: '1.5px solid #e2e8f0', fontSize: 14, outline: 'none', boxSizing: 'border-box', color: '#0f172a' }} />
                  <button onClick={() => setShowPassword(!showPassword)} style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: '#64748b' }}>
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
                <p style={{ fontSize: 11, color: '#94a3b8', margin: '4px 0 0' }}>Share this password with the agent. They'll use it to log in.</p>
              </div>
              <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
                <button onClick={() => { setShowCreateAgent(false); setNewName(''); setNewEmail(''); setNewPassword(''); }}
                  style={{ flex: 1, padding: '11px', borderRadius: 10, background: '#f1f5f9', color: '#374151', border: 'none', fontWeight: 600, cursor: 'pointer' }}>
                  Cancel
                </button>
                <button onClick={createAgent} disabled={creating}
                  style={{ flex: 1, padding: '11px', borderRadius: 10, background: '#0f172a', color: 'white', border: 'none', fontWeight: 700, cursor: creating ? 'not-allowed' : 'pointer', opacity: creating ? 0.7 : 1 }}>
                  {creating ? 'Creating...' : 'Create Agent'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Agents grid */}
      <h3 style={{ fontSize: 15, fontWeight: 700, color: '#0f172a', marginBottom: 12 }}>Support Agents ({agents.length})</h3>
      {agents.length === 0 ? (
        <div style={{ background: 'white', borderRadius: 16, padding: 40, textAlign: 'center', border: '1px solid #e2e8f0', marginBottom: 24 }}>
          <MessageCircle size={36} color="#d1d5db" style={{ margin: '0 auto 12px' }} />
          <p style={{ color: '#6b7280', fontWeight: 600, margin: '0 0 4px' }}>No agents yet</p>
          <p style={{ color: '#9ca3af', fontSize: 13, margin: 0 }}>Create your first support agent above</p>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 12, marginBottom: 24 }}>
          {agents.map(a => (
            <div key={a.id} style={{ background: 'white', borderRadius: 16, padding: 20, border: '1px solid #e2e8f0', display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ width: 44, height: 44, borderRadius: '50%', background: 'linear-gradient(135deg, #1d4ed8, #3b82f6)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <span style={{ color: 'white', fontWeight: 700, fontSize: 16 }}>{a.display_name[0].toUpperCase()}</span>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <p style={{ fontWeight: 700, color: '#0f172a', fontSize: 14, margin: 0 }}>{a.display_name}</p>
                    {a.is_online && <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#22c55e' }} />}
                  </div>
                  <p style={{ fontSize: 12, color: '#64748b', margin: '2px 0 0' }}>{a.email}</p>
                </div>
                <span style={{ fontSize: 11, fontWeight: 700, padding: '3px 10px', borderRadius: 20, background: a.is_active ? '#dcfce7' : '#fee2e2', color: a.is_active ? '#166534' : '#b91c1c' }}>
                  {a.is_active ? 'Active' : 'Inactive'}
                </span>
              </div>
              <p style={{ fontSize: 11, color: '#94a3b8', margin: 0 }}>
                Last seen: {a.last_seen ? new Date(a.last_seen).toLocaleString('en-NG', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'Never'}
              </p>
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => toggleAgentStatus(a.id, a.is_active)}
                  style={{ flex: 1, padding: '8px', borderRadius: 10, background: a.is_active ? '#fef3c7' : '#dcfce7', color: a.is_active ? '#d97706' : '#16a34a', border: 'none', fontWeight: 600, fontSize: 12, cursor: 'pointer' }}>
                  {a.is_active ? 'Deactivate' : 'Activate'}
                </button>
                <button onClick={() => deleteAgent(a.id)} style={{ width: 34, height: 34, borderRadius: 10, background: '#fef2f2', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0 }}>
                  <Trash2 size={14} color="#ef4444" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Recent sessions */}
      <h3 style={{ fontSize: 15, fontWeight: 700, color: '#0f172a', marginBottom: 12 }}>Recent Support Sessions</h3>
      <div style={{ background: 'white', borderRadius: 16, border: '1px solid #e2e8f0', overflow: 'hidden' }}>
        {sessions.length === 0 ? (
          <div style={{ padding: 32, textAlign: 'center' }}>
            <p style={{ color: '#9ca3af', fontSize: 14 }}>No sessions yet</p>
          </div>
        ) : sessions.slice(0, 15).map((s, i) => (
          <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 20px', borderBottom: i < sessions.length - 1 ? '1px solid #f1f5f9' : 'none' }}>
            <div style={{ width: 36, height: 36, borderRadius: '50%', background: '#f1f5f9', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <User size={16} color="#64748b" />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ fontWeight: 600, fontSize: 14, color: '#0f172a', margin: 0 }}>{s.user?.display_name}</p>
              <p style={{ fontSize: 12, color: '#64748b', margin: '2px 0 0' }}>
                {new Date(s.created_at).toLocaleString('en-NG', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
            <span style={{ fontSize: 11, fontWeight: 700, padding: '3px 10px', borderRadius: 20, background: `${statusColor[s.status] || '#94a3b8'}15`, color: statusColor[s.status] || '#94a3b8' }}>
              {s.status.charAt(0).toUpperCase() + s.status.slice(1)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
